Scratch Programs Comparing Methods for Sort
				Linda Pettigrew

These programs are based on the scratch-unplugged-1-0 programs by Moti 
Ben-Ari. Some of the code is copied from the sort programs in this work.

-------------------------------------------------------------------------
The two Scratch programs in this folder show how the different sorts 
work. They can also be used to compare the time taken and number of 
comparisons required by each of the different sort algorithms.

-------------------------------------------------------------------------

Instructions: 
Enter a number of bars for the sort when prompted.
If the number is small you will be asked if you want to see the sort. Type
"n" or "y" to signal your decision.
When the sort is complete the number of comparisons for the sort is 
displayed. Press space to start again with a new set of bars.

-------------------------------------------------------------------------

Quicksort:
 * Highlighted bars indicate that the bars are on the wrong side of the 
   pivot and need to be swapped.
 * Green bars are those that are in their correct position within the
   group of bars.
 * L and H flags indicate the region being partitioned. The first bar - 
   which has an L below it - is the partitioning element.
 * There is no recursion in Scratch so quicksort is implemented using a
   roll-your-own stack which are two lists to which the lower and upper
   bounds are added to the end and retrieved from the end when needed.

Selection sort:
 * Green indicates sorted bars.
 * An arrow points to the current smallest bar in the bars remaining to be 
   sorted.
 * The cat's position indicates the bar currently under consideration.
